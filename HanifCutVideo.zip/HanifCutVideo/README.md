# Hanif Cut Video

Aplikasi Android untuk memotong video secara otomatis menjadi beberapa bagian
(misalnya tiap 3 detik, 1 detik, atau berapa pun) — 100% offline, tanpa
menurunkan kualitas/resolusi, dan audio asli tetap ikut di setiap potongan.

## Cara build TANPA Android Studio (hemat kuota, cocok kalau kuota/wifi terbatas)

Project ini sudah dilengkapi file `.github/workflows/build.yml` yang membuat
**GitHub otomatis membangun APK-nya di server mereka**, jadi kamu tidak perlu
download Android Studio (5-8GB) sama sekali. Yang kamu perlukan cuma:

1. Buka `github.com` di browser (HP atau laptop, bahkan pakai HP saja bisa),
   buat akun gratis kalau belum punya.
2. Klik **"New repository"** → beri nama misalnya `hanif-cut-video` → pilih
   **Public** → klik **Create repository**.
3. Di halaman repo, klik **"uploading an existing file"** (atau menu
   **Add file > Upload files**). Upload SEMUA isi folder `HanifCutVideo` hasil
   extract ZIP ini (bisa drag & drop foldernya sekalian). Total ukurannya
   cuma sekitar 30 KB, jadi sangat ringan/cepat walau kuota kecil.
4. Scroll ke bawah, klik **"Commit changes"**.
5. Klik tab **"Actions"** di bagian atas repo. Proses build akan otomatis
   berjalan (atau kalau belum, klik workflow **"Build APK"** → **"Run workflow"**).
6. Tunggu sekitar 5-10 menit sampai muncul tanda centang hijau ✅ (proses
   build terjadi di server GitHub, tidak memakai kuota HP/laptop kamu sama
   sekali).
7. Klik hasil run yang sudah selesai itu, scroll ke bagian **"Artifacts"**,
   lalu download **"HanifCutVideo-apk"** (file zip kecil, sekitar 15-20 MB).
8. Extract zip tersebut, di dalamnya ada `app-debug.apk`. Pindahkan file ini
   ke HP kamu (lewat kabel data, Bluetooth, WhatsApp ke diri sendiri, Google
   Drive, dll — pilih yang paling hemat kuota buatmu).
9. Di HP, tap file `app-debug.apk` itu untuk install. Kalau muncul peringatan
   "sumber tidak dikenal", tap **"Izinkan/Install saja"** — ini normal untuk
   APK yang tidak dari Play Store.

Selesai — app "Hanif Cut Video" langsung terpasang di HP, tanpa install
Android Studio sama sekali.

## Cara build PAKAI Android Studio (kalau kuota/wifi lancar)

1. Install **Android Studio** terbaru (support Android 16 / API 36).
2. Buka Android Studio → **File > Open** → pilih folder `HanifCutVideo` ini.
3. Kalau muncul dialog "Gradle wrapper is missing" atau semacamnya, klik
   **OK / Create Gradle Wrapper** — Android Studio akan membuatnya otomatis.
4. Tunggu proses **Gradle Sync** selesai (butuh koneksi internet saat sync
   pertama kali untuk download dependency; setelah itu aplikasinya sendiri
   jalan 100% offline di HP).
5. Kalau ada peringatan `compileSdk 36 not found`, buka **Tools > SDK Manager**
   lalu install **Android 16.0 (API 36)**. Atau, kalau mau lebih cepat, ubah
   `compileSdk = 36` dan `targetSdk = 36` di `app/build.gradle.kts` menjadi
   `35` (Android 15), aplikasi tetap tetap jalan normal di Android 16/17
   karena ini cuma versi target compile, bukan pembatas perangkat.
6. Klik tombol **Run ▶** dengan HP/emulator Android terhubung.

## Cara pakai aplikasinya

1. Tekan tombol **"Pilih Video"** → pilih video dari galeri/file manager.
2. Isi kotak **"Durasi tiap potongan (detik)"**, contoh: `3`, `1`, `4`, atau
   angka desimal seperti `2.5`.
3. Tekan **"Potong Video"**.
4. Tunggu sampai selesai. Semua hasil potongan otomatis tersimpan di folder:
   `Movies/HanifCutVideo` (bisa dilihat lewat app Galeri atau File Manager).

## Kenapa durasi potongan bisa sedikit meleset dari angka yang diminta?

Supaya video **tidak di-encode ulang** (artinya resolusi & kualitas video
sama persis dengan aslinya, dan proses jadi cepat), pemotongan dilakukan
dengan metode *stream copy* — video hanya "digunting", bukan diproses ulang.

Metode ini punya syarat: setiap potongan harus dimulai tepat di sebuah
*keyframe* video (titik "kunci" yang sudah ada bawaan dari video aslinya),
supaya potongannya tidak rusak/blank di awal saat diputar. Karena itu, titik
potong otomatis "digeser" sedikit ke keyframe terdekat.

- Kalau video sumbernya punya keyframe rapat (misalnya video dari kamera HP,
  biasanya tiap 1–2 detik), hasil potongan 1 detik akan sangat mendekati 1
  detik.
- Kalau video sumbernya punya keyframe jarang (misalnya video hasil re-encode
  dari aplikasi tertentu), potongannya bisa lebih panjang dari angka yang
  diminta.

Ini satu-satunya cara aman untuk memenuhi permintaan "tidak menurunkan
resolusi sama sekali" sekaligus tetap cepat dan offline. Kalau suatu saat
kamu butuh durasi yang 100% presisi (misal harus pas 1.000 detik) walau
harus re-encode (yang bisa sedikit menurunkan kualitas / lebih lambat),
kasih tahu saya, nanti saya buatkan mode tambahan untuk itu.

## Struktur project

- `app/src/main/java/com/hanif/cutvideo/MainActivity.kt` — layar utama & alur UI.
- `app/src/main/java/com/hanif/cutvideo/VideoSplitter.kt` — logika pemotongan video
  (pakai `MediaExtractor` + `MediaMuxer` bawaan Android, tanpa library luar).
- `app/src/main/res/layout/activity_main.xml` — tampilan hitam polos + tombol ungu.
- Tidak ada permission apa pun yang didaftarkan — aplikasi memakai System File
  Picker (Storage Access Framework) untuk membaca video dan MediaStore untuk
  menyimpan hasil, jadi tidak perlu izin penyimpanan sama sekali.
