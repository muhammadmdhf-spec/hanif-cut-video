package com.hanif.cutvideo

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.hanif.cutvideo.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var selectedVideoUri: Uri? = null
    private var isProcessing = false

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: SecurityException) {
                    // Sebagian provider tidak mendukung persistable permission, tidak masalah,
                    // kita cukup pakai akses sekali pakai yang sudah diberikan.
                }
                selectedVideoUri = uri
                binding.tvNamaFile.text = "Dipilih: " + getFileName(uri)
                binding.btnPotong.isEnabled = true
                binding.tvStatus.text = ""
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPilihVideo.setOnClickListener {
            if (!isProcessing) {
                pickVideoLauncher.launch(arrayOf("video/*"))
            }
        }

        binding.btnPotong.setOnClickListener {
            startSplitting()
        }
    }

    private fun startSplitting() {
        val uri = selectedVideoUri ?: return
        if (isProcessing) return

        val durasiInput = binding.etDurasi.text.toString().trim().replace(",", ".")
        val durasiDetik = durasiInput.toDoubleOrNull()
        if (durasiDetik == null || durasiDetik <= 0.0) {
            Toast.makeText(this, "Masukkan durasi potongan yang valid, contoh: 3", Toast.LENGTH_SHORT).show()
            return
        }
        val segmentDurationUs = (durasiDetik * 1_000_000L).toLong()

        isProcessing = true
        setUiProcessing(true)
        binding.tvStatus.text = "Memulai proses..."

        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    VideoSplitter.split(
                        context = applicationContext,
                        inputUri = uri,
                        segmentDurationUs = segmentDurationUs
                    ) { progress ->
                        lifecycleScope.launch(Dispatchers.Main) {
                            val percent = ((progress.currentPart.toFloat() / progress.estimatedTotalParts.toFloat()) * 100)
                                .toInt().coerceIn(0, 100)
                            binding.progressBar.progress = percent
                            binding.tvStatus.text =
                                "Memproses bagian ${progress.currentPart} dari kira-kira ${progress.estimatedTotalParts}..."
                        }
                    }
                }
                binding.progressBar.progress = 100
                binding.tvStatus.text =
                    "Selesai! ${result.totalParts} video tersimpan di folder Movies/HanifCutVideo"
                Toast.makeText(
                    this@MainActivity,
                    "Selesai! ${result.totalParts} potongan video berhasil dibuat",
                    Toast.LENGTH_LONG
                ).show()
            } catch (e: Exception) {
                binding.tvStatus.text = "Gagal memproses video: ${e.message}"
                Toast.makeText(
                    this@MainActivity,
                    "Terjadi kesalahan: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                isProcessing = false
                setUiProcessing(false)
            }
        }
    }

    private fun setUiProcessing(processing: Boolean) {
        binding.btnPotong.isEnabled = !processing && selectedVideoUri != null
        binding.btnPilihVideo.isEnabled = !processing
        binding.etDurasi.isEnabled = !processing
        binding.progressBar.visibility = if (processing) android.view.View.VISIBLE else binding.progressBar.visibility
        if (processing) binding.progressBar.progress = 0
    }

    private fun getFileName(uri: Uri): String {
        var name = "video"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIndex >= 0 && cursor.moveToFirst()) {
                name = cursor.getString(nameIndex) ?: name
            }
        }
        return name
    }
}
