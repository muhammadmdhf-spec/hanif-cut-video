package com.hanif.cutvideo

import android.content.ContentValues
import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.nio.ByteBuffer

/**
 * Memotong video menjadi beberapa bagian secara otomatis TANPA re-encode
 * (stream copy). Karena tidak di-re-encode:
 *  - Resolusi & kualitas video 100% sama seperti aslinya.
 *  - Audio asli tetap ikut di setiap potongan.
 *  - Proses sangat cepat karena tidak decode/encode ulang.
 *
 * Agar setiap potongan tetap bisa diputar dengan benar (tidak rusak di awal),
 * titik potong otomatis digeser ke keyframe video terdekat. Karena itu durasi
 * tiap potongan bisa sedikit berbeda dari angka yang diminta - ini normal dan
 * satu-satunya cara aman untuk memotong video tanpa menurunkan kualitas.
 */
object VideoSplitter {

    data class Progress(val currentPart: Int, val estimatedTotalParts: Int)

    class SplitResult(val totalParts: Int, val outputNames: List<String>)

    fun split(
        context: Context,
        inputUri: Uri,
        segmentDurationUs: Long,
        onProgress: (Progress) -> Unit
    ): SplitResult {
        require(segmentDurationUs > 0) { "Durasi potongan harus lebih dari 0" }

        val baseName = getDisplayName(context, inputUri).substringBeforeLast(".").ifBlank { "video" }
        val rotationDegrees = getRotationDegrees(context, inputUri)

        // Extractor khusus video (dipakai juga untuk mencari titik keyframe)
        val videoProbe = MediaExtractor().apply { setDataSource(context, inputUri, null) }
        val videoTrackIndex = findTrackIndex(videoProbe, "video/")
        require(videoTrackIndex >= 0) { "File ini tidak punya track video yang valid" }
        videoProbe.selectTrack(videoTrackIndex)
        val videoFormat = videoProbe.getTrackFormat(videoTrackIndex)
        val totalDurationUs = videoFormat.getLong(MediaFormat.KEY_DURATION)

        val audioExtractor = MediaExtractor().apply { setDataSource(context, inputUri, null) }
        val audioTrackIndex = findTrackIndex(audioExtractor, "audio/")
        val hasAudio = audioTrackIndex >= 0
        val audioFormat = if (hasAudio) audioExtractor.getTrackFormat(audioTrackIndex) else null
        if (hasAudio) audioExtractor.selectTrack(audioTrackIndex)

        val estimatedTotalParts =
            ((totalDurationUs + segmentDurationUs - 1) / segmentDurationUs).toInt().coerceAtLeast(1)

        val outputNames = mutableListOf<String>()
        var segmentStartUs = 0L
        var partNumber = 1

        while (segmentStartUs < totalDurationUs) {
            val targetCutUs = segmentStartUs + segmentDurationUs
            val segmentEndUs: Long = if (targetCutUs >= totalDurationUs) {
                totalDurationUs
            } else {
                videoProbe.seekTo(targetCutUs, MediaExtractor.SEEK_TO_NEXT_SYNC)
                val keyframeTime = videoProbe.sampleTime
                if (keyframeTime == -1L || keyframeTime <= segmentStartUs) {
                    totalDurationUs
                } else {
                    keyframeTime
                }
            }

            val outName = "${baseName}_bagian${partNumber.toString().padStart(3, '0')}.mp4"
            writeSegment(
                context = context,
                outputDisplayName = outName,
                videoExtractor = videoProbe,
                videoTrackIndex = videoTrackIndex,
                videoFormat = videoFormat,
                audioExtractor = if (hasAudio) audioExtractor else null,
                audioTrackIndex = audioTrackIndex,
                audioFormat = audioFormat,
                startUs = segmentStartUs,
                endUs = segmentEndUs,
                rotationDegrees = rotationDegrees
            )
            outputNames.add(outName)
            onProgress(Progress(partNumber, estimatedTotalParts))

            segmentStartUs = segmentEndUs
            partNumber++

            // Pengaman anti-infinite-loop untuk file yang aneh/corrupt
            if (partNumber > 200_000) break
        }

        videoProbe.release()
        audioExtractor.release()

        return SplitResult(outputNames.size, outputNames)
    }

    private fun writeSegment(
        context: Context,
        outputDisplayName: String,
        videoExtractor: MediaExtractor,
        videoTrackIndex: Int,
        videoFormat: MediaFormat,
        audioExtractor: MediaExtractor?,
        audioTrackIndex: Int,
        audioFormat: MediaFormat?,
        startUs: Long,
        endUs: Long,
        rotationDegrees: Int
    ) {
        val (outputUri, pfd) = createOutputTarget(context, outputDisplayName)
        val muxer = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        if (rotationDegrees != 0) {
            muxer.setOrientationHint(rotationDegrees)
        }

        val muxerVideoTrack = muxer.addTrack(videoFormat)
        val muxerAudioTrack = if (audioFormat != null) muxer.addTrack(audioFormat) else -1

        muxer.start()

        val bufferSize = 2 * 1024 * 1024
        val buffer = ByteBuffer.allocate(bufferSize)
        val bufferInfo = android.media.MediaCodec.BufferInfo()

        // --- Salin sample video ---
        videoExtractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
        while (true) {
            val sampleTime = videoExtractor.sampleTime
            if (sampleTime == -1L || sampleTime >= endUs) break
            if (videoExtractor.sampleTrackIndex != videoTrackIndex) {
                videoExtractor.advance()
                continue
            }
            buffer.clear()
            val size = videoExtractor.readSampleData(buffer, 0)
            if (size < 0) break
            bufferInfo.offset = 0
            bufferInfo.size = size
            bufferInfo.presentationTimeUs = (sampleTime - startUs).coerceAtLeast(0)
            bufferInfo.flags = mapExtractorFlags(videoExtractor.sampleFlags)
            muxer.writeSampleData(muxerVideoTrack, buffer, bufferInfo)
            videoExtractor.advance()
        }

        // --- Salin sample audio ---
        if (audioExtractor != null && muxerAudioTrack >= 0) {
            audioExtractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            while (true) {
                val sampleTime = audioExtractor.sampleTime
                if (sampleTime == -1L || sampleTime >= endUs) break
                if (audioExtractor.sampleTrackIndex != audioTrackIndex) {
                    audioExtractor.advance()
                    continue
                }
                buffer.clear()
                val size = audioExtractor.readSampleData(buffer, 0)
                if (size < 0) break
                bufferInfo.offset = 0
                bufferInfo.size = size
                bufferInfo.presentationTimeUs = (sampleTime - startUs).coerceAtLeast(0)
                bufferInfo.flags = mapExtractorFlags(audioExtractor.sampleFlags)
                muxer.writeSampleData(muxerAudioTrack, buffer, bufferInfo)
                audioExtractor.advance()
            }
        }

        muxer.stop()
        muxer.release()
        finalizeOutput(context, outputUri)
        pfd.close()
    }

    private fun mapExtractorFlags(extractorFlags: Int): Int {
        var flags = 0
        if (extractorFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) {
            flags = flags or android.media.MediaCodec.BUFFER_FLAG_KEY_FRAME
        }
        return flags
    }

    private fun findTrackIndex(extractor: MediaExtractor, mimePrefix: String): Int {
        for (i in 0 until extractor.trackCount) {
            val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith(mimePrefix)) return i
        }
        return -1
    }

    private fun getDisplayName(context: Context, uri: Uri): String {
        var name = "video"
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (nameIndex >= 0 && cursor.moveToFirst()) {
                name = cursor.getString(nameIndex) ?: name
            }
        }
        return name
    }

    private fun getRotationDegrees(context: Context, uri: Uri): Int {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                ?.toIntOrNull() ?: 0
        } catch (e: Exception) {
            0
        } finally {
            retriever.release()
        }
    }

    /** Membuat entri MediaStore baru di folder Movies/HanifCutVideo dan mengembalikan Uri + FileDescriptor untuk ditulis. */
    private fun createOutputTarget(context: Context, displayName: String): Pair<Uri, android.os.ParcelFileDescriptor> {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/HanifCutVideo")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }
        val uri = resolver.insert(collection, values)
            ?: throw IllegalStateException("Gagal membuat file output untuk $displayName")
        val pfd = resolver.openFileDescriptor(uri, "rw")
            ?: throw IllegalStateException("Gagal membuka file output untuk $displayName")
        return uri to pfd
    }

    private fun finalizeOutput(context: Context, uri: Uri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            context.contentResolver.update(uri, values, null, null)
        }
    }
}
